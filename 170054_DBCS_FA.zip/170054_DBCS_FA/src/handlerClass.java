import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class handlerClass {

	/**********************************************************************************************

	Attributes

	**********************************************************************************************/

	/* Constants used to parameterize the graphical user interface.  We do not use a layout manager for
	   this application. Rather we manually control the location of each graphical element for exact
	   control of the look and feel. */
	private final double BUTTON_WIDTH = 60;
	private final double BUTTON_OFFSET = BUTTON_WIDTH/2;

	// These are the application values required by the user interface
	private Label label_Doublemainline = new Label("Admin Function");
	private Button newRecord = new Button("Add New Record");
	private Button modifyRecord = new Button("Modify New Record ");
	private Button deleteRecord = new Button("Delete Student Record");				
	private Button showRecords = new Button("Get Student Records");				
//	private Button Res_generation = new Button("Result Generation");              
	String s;
	String y;
	
	
	public Label regNumber = new Label("Registration Number: ");
	public Label rnumber_lbl = new Label("Roll Number: ");
	public Label name_lbl = new Label("Name: ");
	public Label fathe_lbl = new Label("Father Name: ");
	public Label mother_lbl = new Label("Mother Name: ");
	public Label course_lbl = new Label("Course: ");
	public Label sem_lbl = new Label("Semester: ");
	public Label year_lbl = new Label("Year: ");

	public TextField regNO = new TextField();
	public TextField RollNumber = new TextField();
	public TextField name = new TextField();
	public TextField fatherName = new TextField();
	public TextField motherName = new TextField();
	
	String year[] = { "year1", "year2", "year3" };
	ComboBox<String> combo_box_year = new ComboBox<String>(FXCollections.observableArrayList(year));

	String sem[] = { "Semester 1", "Semester 2", "Semester 3", "Semester 4", "Semester 5", "Semester 6", "Semester 7",
			"Semester 8" };
	ComboBox<String> combo_box_sem = new ComboBox<String>(FXCollections.observableArrayList(sem));

	String courseName[] = { "DataBase & Client Server", "Big Data", "Network & Security", "Statistics - II",
			"Mobile & Applications" };
	ComboBox<String> combobox_courseName = new ComboBox<String>(FXCollections.observableArrayList(courseName));
	
	
	public Button addRecord = new Button("Add Current Record");
	public Button changeRecord = new Button("Get Corresponding Record");
	public Button deleteData = new Button("Delete Record");
	
	
	



	

	private double buttonSpace;
	                                // This is the white space between the operator buttons.

	/* This is the link to the business logic */
	


	/**********************************************************************************************

	Constructors

	**********************************************************************************************/

	/**********
	 * This method initializes all of the elements of the graphical user interface. These assignments
	 * determine the location, size, font, color, and change and event handlers for each GUI object.
	 */

	

	public handlerClass(Pane theRoot, Stage Stage) {

		// There are five gaps. Compute the button space accordingly.
		buttonSpace = mainline.WINDOW_WIDTH / 5;

		// Label theScene with the name of the mainline, centered at the top of the pane
		setupLabelUI(label_Doublemainline, "Arial", 24, mainline.WINDOW_WIDTH, Pos.CENTER, 0, 10);

		// Label the operand1 just above it, left aligned
		

		
		setupButtonUI(newRecord, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace-BUTTON_OFFSET, 50);
	
		
		

			
		newRecord.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				Stage theStage = new Stage();
				theStage.setTitle("Student Information");
				Pane theRoot = new Pane();
				
				setupLabelUI(regNumber, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 80);
				setupLabelUI(rnumber_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 160);
				setupLabelUI(name_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 240);
				setupLabelUI(fathe_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 320);
				setupLabelUI(mother_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 400);
				setupLabelUI(course_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 480);
				setupLabelUI(sem_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 560);
				setupLabelUI(year_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 640);
				
				
				regNO.setLayoutX(600); regNO.setLayoutY(80);
				RollNumber.setLayoutX(550); RollNumber.setLayoutY(160);
				name.setLayoutX(550); name.setLayoutY(240);
				fatherName.setLayoutX(550); fatherName.setLayoutY(320);
				motherName.setLayoutX(550); motherName.setLayoutY(400);
				
				combobox_courseName.setLayoutX(550); combobox_courseName.setLayoutY(480);
				combo_box_sem.setLayoutX(550); combo_box_sem.setLayoutY(560);
				combo_box_year.setLayoutX(550); combo_box_year.setLayoutY(640);
				
				
				setupButtonUI(addRecord, "Symbol", 18, BUTTON_WIDTH, Pos.BASELINE_CENTER, 550, 750);
					
				Button button_Back = new Button("Back");
				setupButtonUI(button_Back, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 750, 750);
				button_Back.setMinHeight(50);
				button_Back.setMinWidth(100);

//				progressBarIndicator.setVisible(false);
//				progressBarIndicator.setLayoutX(950); progressBarIndicator.setLayoutY(390);
				button_Back.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						theStage.hide();
					}
				});

				

				addRecord.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							addData();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

				Scene secondScene = new Scene(theRoot, 230, 100);
				theStage.setMaximized(true);
				theStage.setScene(secondScene);
				theRoot.getChildren().addAll(regNumber, rnumber_lbl, name_lbl, fathe_lbl, mother_lbl, course_lbl, sem_lbl,year_lbl
						, regNO, button_Back, name, RollNumber, fatherName, addRecord, motherName, combo_box_sem, combo_box_year, combobox_courseName);
				theStage.show();
			}
		});
		
		
		
		setupButtonUI(modifyRecord, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_LEFT, 2.3 * buttonSpace-BUTTON_OFFSET, 100);
		
		
		
		modifyRecord.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				Stage theStage = new Stage();
				theStage.setTitle("Student Information");
				Pane theRoot = new Pane();
				
				setupLabelUI(regNumber, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 80);
				setupLabelUI(rnumber_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 160);
				setupLabelUI(name_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 240);
				setupLabelUI(fathe_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 320);
				setupLabelUI(mother_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 400);
				setupLabelUI(course_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 480);
				setupLabelUI(sem_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 560);
				setupLabelUI(year_lbl, "Arial", 18, 50, Pos.BASELINE_LEFT, 400, 640);
				
				
				regNO.setLayoutX(600); regNO.setLayoutY(80);
				RollNumber.setLayoutX(550); RollNumber.setLayoutY(160);
				name.setLayoutX(550); name.setLayoutY(240);
				fatherName.setLayoutX(550); fatherName.setLayoutY(320);
				motherName.setLayoutX(550); motherName.setLayoutY(400);
				
				combobox_courseName.setLayoutX(550); combobox_courseName.setLayoutY(480);
				combo_box_sem.setLayoutX(550); combo_box_sem.setLayoutY(560);
				combo_box_year.setLayoutX(550); combo_box_year.setLayoutY(640);
				
				
				setupButtonUI(changeRecord, "Symbol", 14, BUTTON_WIDTH, Pos.BASELINE_CENTER, 800, 78);
				setupButtonUI(addRecord, "Symbol", 18, BUTTON_WIDTH, Pos.BASELINE_CENTER, 550, 750);
					
				
				
				
				changeRecord.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							getExistingData();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});

				Button button_Back = new Button("Back");
				setupButtonUI(button_Back, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 750, 750);
				button_Back.setMinHeight(50);
				button_Back.setMinWidth(100);

//				progressBarIndicator.setVisible(false);
//				progressBarIndicator.setLayoutX(950); progressBarIndicator.setLayoutY(390);
				button_Back.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						theStage.hide();
					}
				});

				addRecord.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							getExistingData();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				
				Scene secondScene = new Scene(theRoot, 230, 100);
				theStage.setMaximized(true);
				theStage.setScene(secondScene);
				theRoot.getChildren().addAll(regNumber, rnumber_lbl, name_lbl, fathe_lbl, mother_lbl, course_lbl, sem_lbl,year_lbl
						, regNO, name, button_Back,changeRecord, RollNumber, fatherName, addRecord, motherName, combo_box_sem, combo_box_year, combobox_courseName);
				theStage.show();
			}
		});
		
		
	
		setupButtonUI(deleteRecord, "Symbol", 16, BUTTON_WIDTH + 75, Pos.BASELINE_LEFT, 2.3 * buttonSpace-BUTTON_OFFSET, 150);
		
		deleteRecord.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				Stage theStage = new Stage();
				theStage.setTitle("Student Information");
				Pane theRoot = new Pane();
				
			

				TextField getData = new TextField();
				getData.setLayoutX(100); getData.setLayoutY(150);
				Button button_Back = new Button("Back");
				Button button_delete = new Button("Delete Record");
				button_delete.setLayoutX(150); button_delete.setLayoutY(350);
				
				setupButtonUI(button_Back, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 150, 250);
				button_Back.setMinHeight(50);
				button_Back.setMinWidth(100);

//				progressBarIndicator.setVisible(false);
//				progressBarIndicator.setLayoutX(950); progressBarIndicator.setLayoutY(390);
				button_Back.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						theStage.hide();
					}
				});

				addRecord.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						try {
							getExistingData();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				
				Scene secondScene = new Scene(theRoot, 400, 400);
//				theStage.setMaximized(true);
				theStage.setScene(secondScene);
				theRoot.getChildren().addAll(getData, button_delete, button_Back);
				theStage.show();
			}
		});

////		deleteRecord.setOnAction((event) -> { try {
////			grade(Stage);
////		} catch (FileNotFoundException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
//	});
		
		setupButtonUI(showRecords, "Symbol", 16, BUTTON_WIDTH + 75, Pos.BASELINE_LEFT, 2.3 * buttonSpace-BUTTON_OFFSET, 200);

//		setupButtonUI(Res_generation, "Symbol", 16, BUTTON_WIDTH - 25, Pos.BASELINE_LEFT, 2.3 * buttonSpace-BUTTON_OFFSET, 250);
	


		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(label_Doublemainline, newRecord, modifyRecord, deleteRecord, showRecords );

	}
							
							

	/*******
	 * This public methods invokes the methods of mainline class and generate a specific error
	 * message when the user enters the value of operand1
	 *
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	

	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
	
	
	
	
	
	
	public void addData() throws SQLException
	{
			// providing JDBC credentials
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3308/final", "root", "root");
			Statement st = con.createStatement();
			
			String sqlqurry = "truncate table studentData";
			st.executeUpdate(sqlqurry);
			
			
			String sql = "INSERT INTO studentdata(regNumber,rollNumber, Name, fatherName, motherName, Course, Semester, Year) "
					+ "VALUES('"+regNO.getText().toString()+"', '"+RollNumber.getText().toString() + "','"+name.getText().toString()
					+"','"+fatherName.getText().toString() + "', '"+motherName.getText().toString() + "','"+combobox_courseName.getSelectionModel().getSelectedItem()
					+"','"+combo_box_sem.getSelectionModel().getSelectedItem() + "','" + combo_box_year.getSelectionModel().getSelectedItem()+"');";

			st.executeUpdate(sql);
			
			st.close();
			con.close();
			
			System.out.print("Added..");
			
		
			Alert alert = new Alert(AlertType.CONFIRMATION, "Student Data has been Inserted and Saved Successfully..!",
					ButtonType.OK);
			alert.showAndWait();
		
	}
	
	
	public void getExistingData() throws SQLException
	{
		// providing JDBC credentials
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3308/final", "root", "root");
				Statement st = con.createStatement();
				
				// Executing query to show data from the table in specified order
				
				String retriveRecord_querry = "Select * from studentData where regNumber = " + regNO.getText();
				ResultSet result = st.executeQuery(retriveRecord_querry);
				
				while(result.next())
				{
					
					int rolNumber = result.getInt("rollNumber");
					RollNumber.setText(String.valueOf(rolNumber));
					name.setText(result.getString("Name"));
					fatherName.setText(result.getString("fatherName"));
					motherName.setText(result.getString("motherName"));
					System.out.println("\n");
					
				}
				
				Alert alert = new Alert(AlertType.CONFIRMATION, "Data fetched Successfully..!",
						ButtonType.OK);
				alert.showAndWait();
			}
	}

	











