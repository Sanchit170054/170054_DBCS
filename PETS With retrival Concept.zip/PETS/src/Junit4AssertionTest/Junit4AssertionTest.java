package Junit4AssertionTest;

import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;

import org.junit.Test;
import actions.*;
import actions.ListItem.getData;

public class Junit4AssertionTest{				

		@Test		
	    public void stepsTabTesting(){					
	        		
		   String preConditionValue = ListItem.preCondition;
		   String expectedValue = "Condition1";
		   assertNotSame(preConditionValue, expectedValue);
	
		   String postConditionValue = ListItem.postCondition;
		   String expectedValue1 = "Condition";
		   assertNotSame(postConditionValue, expectedValue1);
		   
		   String taskName = ListItem.taskName;
		   String expectedValue2 = "Task1";
		   assertNotSame(taskName, expectedValue2);
		   
	   
	    }		
		
		@Test		
	    public void taskTabTesting(){					
	        		
			 String effortCateogoryType = ListItem.effortCategoryType;
			   String expectedValue = "Effort1";
			   assertNotSame(effortCateogoryType, expectedValue);
		
			   String useArtifact = ListItem.usedArtifact;
			   String expectedValue1 = "Artifact7";
			   assertNotSame(useArtifact, expectedValue1);
			   
			   String producedArtifact = ListItem.producedArtifact;
			   String expectedValue2 = "Artifact7";
			   assertNotSame(producedArtifact, expectedValue2);
			   
	    }	
		
		@Test		
	    public void ConditionTabTesting(){					
	        		
	    String stateValue = ListItem.defaultCondition;    
	    String expectedValue = "True";
	    	assertNotSame(stateValue, expectedValue);
		
	    }	
		
		@Test		
	    public void EffortCategoryTabTesting(){					
	        		
			 String effortKind = ListItem.effortSelected;
			   String expectedValue = "Artifacts";
			   assertNotSame(effortKind, expectedValue);
		
			   String selectedOption = ListItem.optionSelected;
			   String expectedValue1 = "Artifact7";
			   assertNotSame(selectedOption, expectedValue1);
			   		   
	    }	
		@Test		
	    public void OtherTabsTesting(){					
	        		
			 String effortKind = ListItem.updatedValue;
			   String expectedValue = "Lifecycle1";
			   assertNotSame(effortKind, expectedValue);
				   		   
	    }	
		
		
	}		


