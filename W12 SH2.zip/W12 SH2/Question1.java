import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Question1
{
	public static void main(String[] args) throws SQLException
	{
		try {
			
			// providing JDBC credentials
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/W12_SH2", "root", "root");
		Statement st = con.createStatement();
		
		// Execute a query to create a table
		String query = "CREATE table Employees(Emp_ID int, First_name varchar(20), Last_name varchar(20), "
				+ "Salary int, Dept_ID int, Email varchar(25), City varchar(20))";
		st.executeUpdate(query);

		st.close();
		con.close();
		System.out.print("Table is created..!");
		
		}
		
		catch (Exception e) {
		
			System.out.print("Table already exists..");
		}
				
	}
}