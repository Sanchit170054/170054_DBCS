import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Question4 {

	public static void main(String[] args) throws SQLException
	{
	
		
			// providing JDBC credentials
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/W12_SH2", "root", "root");
			Statement st = con.createStatement();
		
			// Executing query to update names at index 5
			
			String update_querry = "update Employees set First_name = 'Shubham', Last_name = 'Walia' where Emp_ID = 5 ";
			st.executeUpdate(update_querry);
			
			// querry to retrive the record
			String retriveRecord_querry = "Select First_name, Last_name from Employees where Emp_ID = 5 ;";
			ResultSet result = st.executeQuery(retriveRecord_querry);
			
			// using resultset to print the values
			
			while(result.next())
			{
			
			System.out.print("New value at Emp_ID 5 : " + result.getString("First_name") + " " + result.getString("Last_name") +"  ");
				
				System.out.println("\n");
			}		
			
				
	}

}
