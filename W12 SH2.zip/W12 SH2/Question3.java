import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Question3 {

	public static void main(String[] args)
	{
		try
		{
			// providing JDBC credentials
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/W12_SH2", "root", "root");
			Statement st = con.createStatement();
			
			// Executing query to retrive the data from the table
			
			String retriveRecord_querry = "Select * from Employees;";
			ResultSet result = st.executeQuery(retriveRecord_querry);
			
			// check if there is next value, if yes then print it
			while(result.next())
			{
				System.out.print("Emplopye ID : " + result.getString("Emp_ID") +" ");
				System.out.print("Emplopye Name : " + result.getString("First_name") + " " + result.getString("Last_name") +"  ");
				System.out.print("Emplopye Salary : " + result.getInt("Salary") +" ");
				System.out.print("Emplopye Department : " + result.getInt("Dept_ID") +" ");
				System.out.print("Emplopye EmailID : " + result.getString("Email") +" ");
				System.out.print("Emplopye City : " + result.getString("City") +" ");
				
				System.out.println("\n");
				
			}
			System.out.print("\nContent is retrived..");
		}
		catch (Exception e) {
			System.out.print("Some Error Occured..!");
		}
	}
}
