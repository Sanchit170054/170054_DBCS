import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Question7 {

	public static void main(String[] args) throws SQLException
	{
		// providing JDBC credentials
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/W12_SH2", "root", "root");
		Statement st = con.createStatement();
		
		// Executing query to fetch department ID and average salary 
		
		String retriveRecord_querry = "Select Dept_ID, avg(Salary) from Employees group by(Dept_ID)";
		ResultSet result = st.executeQuery(retriveRecord_querry);
		
		while(result.next())
		{
		
			System.out.print("Emplopye Salary : " + result.getDouble("avg(Salary)") +" ");
			System.out.print("Emplopye Department : " + result.getInt("Dept_ID") +" ");
			
			System.out.println("\n");
			
		}
	}		

}
