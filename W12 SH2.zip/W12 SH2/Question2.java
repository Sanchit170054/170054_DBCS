import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Question2 {

	public static void main(String[] args)
	{
		try
		{
			// providing JDBC credentials
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/W12_SH2", "root", "root");
			Statement st = con.createStatement();
			
			// Executing query to insert values into the table
			
			String insert_querry = "Insert Into Employees values (1,'Sanchit', 'Sharma', 100000, 01, '@gmail.com', 'YNR')";
			st.executeUpdate(insert_querry);
			insert_querry = "Insert Into Employees values (2,'Dolly', 'Chandel', 50000, 01, '@gmail.com', 'YNR')";
			st.executeUpdate(insert_querry);
			insert_querry = "Insert Into Employees values (3,'Puneet', 'Garg', 60000, 02, '@gmail.com','Delhi')";
			st.executeUpdate(insert_querry);
			insert_querry = "Insert Into Employees values (4,'Vaibhav', 'Pahwa', 90000, 01, '@gmail.com', 'Delhi')";
			st.executeUpdate(insert_querry);
			insert_querry = "Insert Into Employees values (5,'Sumit', 'Singh', 50000, 02, '@gmail.com', 'Chandigarh')";
			st.executeUpdate(insert_querry);
			insert_querry = "Insert Into Employees values (6,'Vinit', 'Bishnoi', 50000, 02, '@gmail.com','Mumbai')";
			st.executeUpdate(insert_querry);
			insert_querry = "Insert Into Employees values (7,'Sumit', 'Soni', 60000, 03, '@gmail.com','Chandigarh')";
			st.executeUpdate(insert_querry);
			insert_querry = "Insert Into Employees values (8,'Abhinav', 'Yadav', 70000, 03, '@gmail.com', 'Chandigarh')";
			st.executeUpdate(insert_querry);
		

			st.close();
			con.close();
			
			System.out.print("Table Updated..");
		}
		
		catch (Exception e) {

			System.out.print("Some Error occured..");
		}
	}

}
