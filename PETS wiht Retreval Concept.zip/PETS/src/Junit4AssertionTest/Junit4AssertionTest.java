package Junit4AssertionTest;

import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;

import org.junit.Test;
import actions.*;
import actions.ListItem.getData;

public class Junit4AssertionTest{				

		@Test		
	    public void stepsTabTesting(){					
	        		
		   String conditonCombobxFetchedData = ListItem.preCondition;
		   String databaseFetchedValue1 = ListItem.conditonComboboxValue;
		   assertNotSame(conditonCombobxFetchedData, databaseFetchedValue1);
	
		   String postConditonCombobxFetchedData = ListItem.postCondition;
		   String databaseFetchedValue2 = ListItem.postConditionComboboxValue;
		   assertNotSame(postConditonCombobxFetchedData, databaseFetchedValue2);
		   
		   String taskComboboxFetchedData = ListItem.taskName;
		   String databaseFetchedValue3 = ListItem.taskComboboxValue;
		   assertNotSame(taskComboboxFetchedData, databaseFetchedValue3);
		   
	   
	    }		
		
		@Test		
	    public void taskTabTesting(){					
	        		
			 String effortTypeCombobxFetchedData = ListItem.effortCategoryType;
			   String databaseFetchedValue1 = ListItem.effortCategoryComboboxValue;
			   assertNotSame(effortTypeCombobxFetchedData, databaseFetchedValue1);
		
			   String usedArtifactCombobxFetchedData = ListItem.usedArtifact;
			   String databaseFetchedValue2 = ListItem.usedComboboxValue;
			   assertNotSame(usedArtifactCombobxFetchedData, databaseFetchedValue2);
			   
			   String producedArtifactComboboxFetchedData = ListItem.producedArtifact;
			   String databaseFetchedValue3 = ListItem.producedComboboxValue;
			   assertNotSame(producedArtifactComboboxFetchedData, databaseFetchedValue3);
			   
			
			   
	    }	
		
		@Test		
	    public void ConditionTabTesting(){					
	        		
	    String defaultStateFetchedValue = ListItem.defaultCondition;    
	    String databaseFetchedValue1 = ListItem.defaultStateCombobxValue;
	    	assertNotSame(defaultStateFetchedValue, databaseFetchedValue1);
		
	    }	
		
		@Test		
	    public void EffortCategoryTabTesting(){					
	        		
			 String selectedEffortFetchedValue = ListItem.effortSelected;
			   String databaseFetchedValue1 = ListItem.selectedOption;
			   assertNotSame(selectedEffortFetchedValue, databaseFetchedValue1);
		
			   String artifactOptionsFetchedValue = ListItem.optionSelected;
			   String databaseFetchedValue2 = ListItem.artifactSelectedOption;
			   assertNotSame(artifactOptionsFetchedValue, databaseFetchedValue2);
			   		   
	    }	
		@Test		
	    public void OtherTabsTesting(){					
	        		
			 String nameFieldFetchedValue = ListItem.updatedValue;
			   String databaseFetchedValue1 = ListItem.nameFieldValue;
			   assertNotSame(nameFieldFetchedValue, databaseFetchedValue1);
			
			   String DescriptionFieldFetchedValue = ListItem.updatedValue;
			   String databaseFetchedValue2 = ListItem.descFieldValue;
			   assertNotSame(DescriptionFieldFetchedValue, databaseFetchedValue2);
	    }	
		
		
	}		


